package com.example.week1_0706012010045MobApp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import Model.User;

public class UserRVAdapter extends RecyclerView.Adapter<UserRVAdapter.BarangViewHolder>{

    private ArrayList<User>ListUser;
    protected OnCardListener cardListener;

    public UserRVAdapter(ArrayList<User> listUser, OnCardListener cardListener) {
        this.cardListener = cardListener;
        this.ListUser = listUser;
    }

    @NonNull
    @Override
    public BarangViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.card_user, parent, false);
        return new BarangViewHolder(view, cardListener);
    }

    @Override
    public void onBindViewHolder(@NonNull BarangViewHolder holder, int position) {
        holder.card_fullname.setText(ListUser.get(position).getFullname());
        holder.card_age.setText(String.valueOf(ListUser.get(position).getAge()));
        holder.card_address.setText(ListUser.get(position).getAddress());
    }

    @Override
    public int getItemCount() {
        return ListUser.size();
    }

    public class BarangViewHolder extends RecyclerView.ViewHolder {

        private TextView card_fullname, card_age, card_address;
        private ImageView card_image_item;

        public BarangViewHolder(@NonNull View itemView, OnCardListener cardListener) {
            super(itemView);
            card_fullname = itemView.findViewById(R.id.card_fullname);
            card_age = itemView.findViewById(R.id.card_age);
            card_address = itemView.findViewById(R.id.card_address);
            card_image_item = itemView.findViewById(R.id.card_image_item);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cardListener.onCardClick(getAdapterPosition());
                }
            });
        }
    }
}