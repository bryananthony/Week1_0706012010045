package com.example.week1_0706012010045MobApp;

public interface OnCardListener {
    void onCardClick(int position);
}
